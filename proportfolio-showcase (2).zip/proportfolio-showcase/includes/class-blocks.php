<?php
/**
 * Gutenberg Block registration.
 *
 * Registers the server-side rendered Portfolio Grid block via block.json.
 *
 * @package ProPortfolio_Showcase
 */

namespace ProPortfolio\Includes;

defined( 'ABSPATH' ) || exit;

/**
 * Handles Gutenberg block registration and block patterns.
 */
class Blocks {

	/**
	 * Register the Portfolio Grid block.
	 *
	 * Uses block.json for metadata and a PHP render callback.
	 * No JavaScript build step required — fully server-side rendered.
	 *
	 * @return void
	 */
	public function register_block() {
		$block_path = PROPORTFOLIO_PATH . 'blocks/portfolio-grid';

		if ( ! file_exists( $block_path . '/block.json' ) ) {
			return;
		}

		register_block_type( $block_path );
	}

	/**
	 * Register block patterns.
	 *
	 * @return void
	 */
	public function register_block_patterns() {
		if ( ! function_exists( 'register_block_pattern' ) ) {
			return;
		}

		register_block_pattern(
			'proportfolio/portfolio-grid',
			array(
				'title'       => __( 'Portfolio Grid', 'proportfolio-showcase' ),
				'description' => __( 'A responsive grid of portfolio projects with optional category filtering.', 'proportfolio-showcase' ),
				'content'     => '<!-- wp:proportfolio/portfolio-grid {"count":6,"columns":3,"showFilter":true} /-->',
				'categories'  => array( 'proportfolio' ),
				'keywords'    => array( 'portfolio', 'projects', 'grid', 'gallery' ),
			)
		);
	}

	/**
	 * Register block pattern categories.
	 *
	 * @return void
	 */
	public function register_block_pattern_categories() {
		if ( ! function_exists( 'register_block_pattern_category' ) ) {
			return;
		}

		register_block_pattern_category(
			'proportfolio',
			array(
				'label' => __( 'ProPortfolio', 'proportfolio-showcase' ),
			)
		);
	}
}